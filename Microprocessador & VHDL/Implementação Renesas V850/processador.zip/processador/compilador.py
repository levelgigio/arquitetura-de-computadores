from numpy import binary_repr

commands = [
    "ADDI R1 0",
    "ADDI R2 1",
    "ADDI R3 32",
    "ST.W R1 R1",
    "ADD R2 R1",
    "CMP R3 R1",
    "BLT -4",
    "ADDI R4 1",
    "ADD R2 R4",
    "ADDI R1 0",
    "ADDI R5 0",
    "ADD R4 R1",
    "ADD R4 R5",
    "ADD R5 R1",
    "ST.W R0 R1",
    "CMP R3 R1",
    "BLT -4",
    "CMP R3 R5",
    "BLT -11",
    "ADDI R1 0",
    "ADDI R2 1",
    "ADDI R3 32",
    "LD.W R1 R4",
    "ADD R2 R1",
    "CMP R3 R1",
    "BLT -4",
]

# commands = [
#     "ADDI R1 0",
#     "ADDI R2 1",
#     "ADDI R3 5",
#     "ST.W R1 R0",
#     "ADD R2 R1",
#     "CMP R3 R1",
#     "LD.W R0 R4",
#     "BLT -5",
#     "ST.W R3 R2",
#     "ADDI R7 60",
#     "ST.W R4 R7",
#     "LD.W R0 R4",
# ]

def register_map(register):
    return {
        "R0": "000",
        "R1": "001",
        "R2": "010",
        "R3": "011",
        "R4": "100",
        "R5": "101",
        "R6": "110",
        "R7": "111",
    }[register]

for index, command in enumerate(commands):
    print("-- " + command)
    mapa = {
        "ADD": lambda: "0001"
        + register_map(command.split()[1])
        + register_map(command.split()[2])
        + "0000",

        "ADDI": lambda: "0010"
        + register_map(command.split()[1])
        + str(binary_repr(int(command.split()[2]), width=7)),

        "SUB": lambda: "0011"
        + register_map(command.split()[1])
        + register_map(command.split()[2])
        + "0000",

        "MOV": lambda: "0100"
        + register_map(command.split()[1])
        + register_map(command.split()[2])
        + "0000",

        "JMP": lambda: "0101"
        + str(binary_repr(int(command.split()[1]), width=7))
        + "0000",

        "CMP": lambda: "0110"
        + register_map(command.split()[1])
        + register_map(command.split()[2])
        + "0000",
        
        "BLT": lambda: "0111"
        + str(binary_repr(int(command.split()[1]), width=7))
        + "000",

        "LD.W": lambda: "1000"
        + register_map(command.split()[1])
        + register_map(command.split()[2])
        + "0000",

        "ST.W": lambda: "1001"
        + register_map(command.split()[2])
        + register_map(command.split()[1])
        + "0000",
    }
    print(str(index) + ' => "' + mapa[command.split()[0]]() + '",')

print("others => (others=>'0')")
