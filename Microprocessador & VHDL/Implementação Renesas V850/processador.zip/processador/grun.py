import os
import sys

os.system("rm -rf work-obj93.cf")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a reg7bits.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e reg7bits")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a reg7bits_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e reg7bits_tb")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r reg7bits_tb --stop-time=1000ns --wave=reg7bits_tb.ghw")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a reg8bits.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e reg8bits")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a reg1bit.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e reg1bit")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a reg8bits_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e reg8bits_tb")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r reg8bits_tb --stop-time=1000ns --wave=reg8bits_tb.ghw")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a register_bank.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e register_bank")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a register_bank_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e register_bank_tb")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r register_bank_tb --stop-time=1600ns --wave=register_bank_tb.ghw")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a ula.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e ula")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a ula_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e ula_tb")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a ula_register.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e ula_register")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a ula_register_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e ula_register_tb")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a pc.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e pc")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a pc_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e pc_tb")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r pc_tb --stop-time=1500ns --wave=pc_tb.ghw")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a rom.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e rom")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a rom_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e rom_tb")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r rom_tb --stop-time=1000ns --wave=rom_tb.ghw")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a rom_pc.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e rom_pc")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a rom_pc_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e rom_pc_tb")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a rom_pc_ula_register.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e rom_pc_ula_register")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a rom_pc_ula_register_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e rom_pc_ula_register_tb")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a state_machine.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e state_machine")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a state_machine_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e state_machine_tb")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a ram.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e ram")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a control_unit.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e control_unit")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a processador.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e processador")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -a processador_tb.vhdl")
os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -e processador_tb")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r rom_pc_tb --stop-time=3000ns --wave=rom_pc_tb.ghw")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r rom_pc_ula_register_tb --stop-time=3000ns --wave=rom_pc_ula_register_tb.ghw")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r ula_register_tb --stop-time=3000ns --wave=ula_register_tb.ghw")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r ula_tb --stop-time=3000ns --wave=ula_tb.ghw")

# os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r processador_tb --stop-time=3000ns --wave=processador_tb.ghw")

os.system("../ghdl-0.36-macosx-mcode/bin/ghdl -r processador_tb --stop-time=210000ns --wave=processador_alt_tb.ghw")